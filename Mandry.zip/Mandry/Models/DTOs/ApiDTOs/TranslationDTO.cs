﻿namespace Mandry.Models.DTOs.ApiDTOs
{
    public class TranslationDTO
    {
        public string Key { get; set; } = string.Empty;
        public string LanguageCode { get; set; } = string.Empty;
        public string Text {  get; set; } = string.Empty;
    }
}
