﻿namespace Mandry.Models.Requests.Authentication
{
    public class PhoneModel
    {
        public string Phone { get; set; }
    }
}
