﻿namespace Mandry.Models.Requests.Authentication
{
    public class EmailPasswordModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
