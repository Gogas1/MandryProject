﻿using Microsoft.AspNetCore.Mvc;

namespace Mandry.Controllers
{
    [Route("housing")]
    public class HousingController : Controller
    {
        
    }
}
